import { ArrowRight, Sun, Zap, TrendingUp, Users } from 'lucide-react';

interface HeroProps {
  onStartSimulation: () => void;
}

export function Hero({ onStartSimulation }: HeroProps) {
  return (
    <>
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <div className="inline-flex items-center px-4 py-2 bg-green-100 text-green-700 rounded-full mb-6">
              <span className="mr-2">🌍</span>
              <span>Plateforme N°1 du Photovoltaïque en Tunisie</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-green-600 via-blue-600 to-yellow-500 bg-clip-text text-transparent">
              Passez à l'Énergie Solaire
              <br />
              en Toute Simplicité
            </h1>
            
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              SolarEZ digitalise votre projet photovoltaïque de A à Z : simulation gratuite, devis instantané, 
              installateurs certifiés, formations et emplois dans le solaire.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <button 
                onClick={onStartSimulation}
                className="group px-8 py-4 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-2xl transition-all transform hover:scale-105 flex items-center justify-center"
              >
                Simulation Gratuite
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
              </button>
              <button className="px-8 py-4 border-2 border-green-500 text-green-600 rounded-lg hover:bg-green-50 transition">
                Découvrir la plateforme
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {[
                { icon: Sun, label: 'Installateurs', value: '150+' },
                { icon: Users, label: 'Clients Satisfaits', value: '2,000+' },
                { icon: Zap, label: 'kWh Produits/an', value: '15M+' },
                { icon: TrendingUp, label: 'ROI Moyen', value: '7-8 ans' },
              ].map((stat, index) => (
                <div key={index} className="bg-white p-6 rounded-xl shadow-md">
                  <stat.icon className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-20 left-10 w-72 h-72 bg-yellow-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-72 h-72 bg-green-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-pulse" style={{ animationDelay: '1s' }}></div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Une Plateforme, Tout l'Écosystème
            </h2>
            <p className="text-xl text-gray-600">
              SolarEZ centralise tous les acteurs du photovoltaïque en Tunisie
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: '💡',
                title: 'Simulation & Devis',
                description: 'Bilan énergétique personnalisé et devis instantané basé sur votre consommation réelle',
                color: 'from-yellow-400 to-orange-500'
              },
              {
                icon: '🔧',
                title: 'Installateurs Certifiés',
                description: 'Réseau d\'installateurs qualifiés et vérifiés partout en Tunisie',
                color: 'from-green-400 to-blue-500'
              },
              {
                icon: '🎓',
                title: 'Formations & Emploi',
                description: 'Accédez aux formations photovoltaïques et opportunités de carrière',
                color: 'from-blue-400 to-purple-500'
              },
              {
                icon: '📦',
                title: 'Marketplace Fournisseurs',
                description: 'Catalogue complet de matériel solaire : panneaux, onduleurs, batteries',
                color: 'from-purple-400 to-pink-500'
              },
              {
                icon: '📊',
                title: 'ROI Transparent',
                description: 'Calculez précisément votre retour sur investissement et vos économies sur 25 ans',
                color: 'from-green-500 to-teal-500'
              },
              {
                icon: '🌍',
                title: 'Impact Environnemental',
                description: 'Visualisez votre contribution à la réduction des émissions de CO₂',
                color: 'from-teal-400 to-green-500'
              },
            ].map((feature, index) => (
              <div key={index} className="group relative bg-gradient-to-br from-gray-50 to-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all transform hover:-translate-y-2">
                <div className={`w-16 h-16 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition-transform`}>
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gradient-to-b from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Comment Ça Marche ?
            </h2>
            <p className="text-xl text-gray-600">
              Votre projet solaire en 4 étapes simples
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                step: '01',
                title: 'Simulation',
                description: 'Répondez à quelques questions sur votre consommation et votre habitation'
              },
              {
                step: '02',
                title: 'Devis Instantané',
                description: 'Recevez votre devis détaillé avec calcul de rentabilité en temps réel'
              },
              {
                step: '03',
                title: 'Choisissez un Installateur',
                description: 'Comparez et sélectionnez un installateur certifié près de chez vous'
              },
              {
                step: '04',
                title: 'Installation',
                description: 'Planifiez votre installation et commencez à économiser'
              },
            ].map((item, index) => (
              <div key={index} className="relative">
                <div className="text-6xl font-bold text-green-100 mb-4">{item.step}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
                {index < 3 && (
                  <div className="hidden md:block absolute top-12 -right-4 text-4xl text-green-300">→</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-600 to-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Prêt à Passer à l'Énergie Solaire ?
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Obtenez votre simulation gratuite en moins de 2 minutes
          </p>
          <button 
            onClick={onStartSimulation}
            className="px-10 py-4 bg-white text-green-600 rounded-lg hover:shadow-2xl transition-all transform hover:scale-105 inline-flex items-center"
          >
            Commencer Ma Simulation
            <ArrowRight className="ml-2" size={20} />
          </button>
        </div>
      </section>
    </>
  );
}
