import { useState } from 'react';
import { Calculator, Home, MapPin, Zap, Compass, Maximize } from 'lucide-react';
import { SimulationResult } from '../App';

interface EnergySimulatorProps {
  onSimulationComplete: (result: SimulationResult) => void;
}

export function EnergySimulator({ onSimulationComplete }: EnergySimulatorProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    buildingType: '',
    region: '',
    roofSurface: '',
    roofType: '',
    orientation: '',
    monthlyBill: '',
    monthlyConsumption: '',
  });

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const calculateSimulation = (): SimulationResult => {
    // Constants from technical documentation (Section 20)
    const AVERAGE_TARIFF = 0.300; // TND/kWh
    const COST_PER_KWC = 3500; // TND
    const PANEL_POWER = 0.4; // kW (400W)
    const PANEL_SURFACE = 1.9; // m²
    const SYSTEM_LOSSES = 0.85;
    const CO2_PER_KWH = 0.5; // kg

    // Regional production (kWh/kWc/year)
    const regionalProduction: { [key: string]: number } = {
      'Nord': 1500,
      'Centre': 1650,
      'Sud': 1800,
    };

    // Orientation factors
    const orientationFactors: { [key: string]: number } = {
      'Sud': 1.00,
      'Est': 0.85,
      'Ouest': 0.85,
      'Nord': 0.65,
    };

    // Roof type factors
    const roofFactors: { [key: string]: number } = {
      'Plat': 1.00,
      'Incliné': 0.95,
    };

    // Calculate monthly consumption
    let monthlyConsumption = parseFloat(formData.monthlyConsumption);
    if (!monthlyConsumption && formData.monthlyBill) {
      monthlyConsumption = parseFloat(formData.monthlyBill) / AVERAGE_TARIFF;
    }

    const annualConsumption = monthlyConsumption * 12;
    const production = regionalProduction[formData.region];
    const orientationFactor = orientationFactors[formData.orientation];
    const roofFactor = roofFactors[formData.roofType];

    // Calculate required power
    const powerKWc = annualConsumption / (production * orientationFactor * roofFactor * SYSTEM_LOSSES);
    
    // Verify surface availability
    const numPanels = Math.ceil(powerKWc / PANEL_POWER);
    const requiredSurface = numPanels * PANEL_SURFACE;
    const availableSurface = parseFloat(formData.roofSurface);
    
    const finalPowerKWc = requiredSurface <= availableSurface 
      ? powerKWc 
      : (availableSurface / PANEL_SURFACE) * PANEL_POWER;
    
    const finalNumPanels = Math.ceil(finalPowerKWc / PANEL_POWER);

    // Calculate production
    const annualProduction = finalPowerKWc * production * orientationFactor * roofFactor * SYSTEM_LOSSES;
    const monthlyProduction = annualProduction / 12;

    // Calculate costs and savings
    const totalCost = finalPowerKWc * COST_PER_KWC;
    const annualEconomies = annualProduction * AVERAGE_TARIFF;
    const monthlyEconomies = annualEconomies / 12;
    const roi = totalCost / annualEconomies;

    // Environmental impact
    const co2Reduction = annualProduction * CO2_PER_KWH;

    return {
      powerKWc: Math.round(finalPowerKWc * 100) / 100,
      numPanels: finalNumPanels,
      totalCost: Math.round(totalCost),
      monthlyEconomies: Math.round(monthlyEconomies),
      annualEconomies: Math.round(annualEconomies),
      roi: Math.round(roi * 10) / 10,
      annualProduction: Math.round(annualProduction),
      co2Reduction: Math.round(co2Reduction),
      monthlyConsumption,
      region: formData.region,
      roofType: formData.roofType,
      orientation: formData.orientation,
    };
  };

  const handleSubmit = () => {
    const result = calculateSimulation();
    onSimulationComplete(result);
  };

  const isStepValid = () => {
    switch(step) {
      case 1:
        return formData.buildingType && formData.region;
      case 2:
        return formData.roofSurface && formData.roofType && formData.orientation;
      case 3:
        return formData.monthlyBill || formData.monthlyConsumption;
      default:
        return false;
    }
  };

  return (
    <section className="py-12 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-green-600 to-blue-600 p-8 text-white">
            <div className="flex items-center mb-4">
              <Calculator size={32} />
              <h2 className="ml-3 text-3xl font-bold">Simulation Énergétique</h2>
            </div>
            <p className="text-green-100">
              Découvrez votre potentiel solaire en quelques clics
            </p>
            
            {/* Progress Bar */}
            <div className="mt-6 flex items-center">
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex items-center flex-1">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                    s <= step ? 'bg-white text-green-600' : 'bg-green-400 text-white'
                  }`}>
                    {s}
                  </div>
                  {s < 3 && (
                    <div className={`h-1 flex-1 mx-2 ${
                      s < step ? 'bg-white' : 'bg-green-400'
                    }`}></div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Form Steps */}
          <div className="p-8">
            {/* Step 1: Building & Location */}
            {step === 1 && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Type de Bâtiment & Localisation</h3>
                
                <div>
                  <label className="flex items-center text-gray-700 mb-3">
                    <Home size={20} className="mr-2 text-green-600" />
                    Type de bâtiment
                  </label>
                  <div className="grid grid-cols-3 gap-4">
                    {['Maison', 'Appartement', 'PME'].map((type) => (
                      <button
                        key={type}
                        onClick={() => updateFormData('buildingType', type)}
                        className={`p-4 rounded-lg border-2 transition ${
                          formData.buildingType === type
                            ? 'border-green-500 bg-green-50 text-green-700'
                            : 'border-gray-200 hover:border-green-300'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="flex items-center text-gray-700 mb-3">
                    <MapPin size={20} className="mr-2 text-green-600" />
                    Région
                  </label>
                  <div className="grid grid-cols-3 gap-4">
                    {['Nord', 'Centre', 'Sud'].map((region) => (
                      <button
                        key={region}
                        onClick={() => updateFormData('region', region)}
                        className={`p-4 rounded-lg border-2 transition ${
                          formData.region === region
                            ? 'border-green-500 bg-green-50 text-green-700'
                            : 'border-gray-200 hover:border-green-300'
                        }`}
                      >
                        {region}
                      </button>
                    ))}
                  </div>
                  <p className="mt-2 text-sm text-gray-500">
                    {formData.region === 'Nord' && '🌤️ Production moyenne: 1 500 kWh/kWc/an'}
                    {formData.region === 'Centre' && '☀️ Production moyenne: 1 650 kWh/kWc/an'}
                    {formData.region === 'Sud' && '🌞 Production moyenne: 1 800 kWh/kWc/an'}
                  </p>
                </div>
              </div>
            )}

            {/* Step 2: Roof Details */}
            {step === 2 && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Caractéristiques du Toit</h3>
                
                <div>
                  <label className="flex items-center text-gray-700 mb-3">
                    <Maximize size={20} className="mr-2 text-green-600" />
                    Surface disponible du toit (m²)
                  </label>
                  <input
                    type="number"
                    value={formData.roofSurface}
                    onChange={(e) => updateFormData('roofSurface', e.target.value)}
                    placeholder="Ex: 50"
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none"
                  />
                  <p className="mt-2 text-sm text-gray-500">
                    💡 Un panneau de 400W nécessite environ 1.9 m²
                  </p>
                </div>

                <div>
                  <label className="flex items-center text-gray-700 mb-3">
                    Type de toit
                  </label>
                  <div className="grid grid-cols-2 gap-4">
                    {['Plat', 'Incliné'].map((type) => (
                      <button
                        key={type}
                        onClick={() => updateFormData('roofType', type)}
                        className={`p-4 rounded-lg border-2 transition ${
                          formData.roofType === type
                            ? 'border-green-500 bg-green-50 text-green-700'
                            : 'border-gray-200 hover:border-green-300'
                        }`}
                      >
                        {type === 'Plat' ? '🏢 Terrasse' : '🏠 Incliné'}
                        <div className="text-sm mt-1">
                          {type === 'Plat' ? 'Facteur: 1.00' : 'Facteur: 0.95'}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="flex items-center text-gray-700 mb-3">
                    <Compass size={20} className="mr-2 text-green-600" />
                    Orientation du toit
                  </label>
                  <div className="grid grid-cols-4 gap-4">
                    {[
                      { dir: 'Sud', factor: '1.00', emoji: '☀️' },
                      { dir: 'Est', factor: '0.85', emoji: '🌅' },
                      { dir: 'Ouest', factor: '0.85', emoji: '🌇' },
                      { dir: 'Nord', factor: '0.65', emoji: '🌥️' },
                    ].map(({ dir, factor, emoji }) => (
                      <button
                        key={dir}
                        onClick={() => updateFormData('orientation', dir)}
                        className={`p-4 rounded-lg border-2 transition ${
                          formData.orientation === dir
                            ? 'border-green-500 bg-green-50 text-green-700'
                            : 'border-gray-200 hover:border-green-300'
                        }`}
                      >
                        <div className="text-2xl mb-1">{emoji}</div>
                        <div>{dir}</div>
                        <div className="text-xs mt-1">x{factor}</div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 3: Energy Consumption */}
            {step === 3 && (
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Consommation Énergétique</h3>
                
                <div>
                  <label className="flex items-center text-gray-700 mb-3">
                    <Zap size={20} className="mr-2 text-green-600" />
                    Facture mensuelle moyenne (TND)
                  </label>
                  <input
                    type="number"
                    value={formData.monthlyBill}
                    onChange={(e) => updateFormData('monthlyBill', e.target.value)}
                    placeholder="Ex: 120"
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none"
                  />
                  {formData.monthlyBill && (
                    <p className="mt-2 text-sm text-green-600">
                      ≈ {Math.round(parseFloat(formData.monthlyBill) / 0.3)} kWh/mois
                    </p>
                  )}
                </div>

                <div className="text-center text-gray-500">OU</div>

                <div>
                  <label className="flex items-center text-gray-700 mb-3">
                    Consommation mensuelle (kWh)
                  </label>
                  <input
                    type="number"
                    value={formData.monthlyConsumption}
                    onChange={(e) => updateFormData('monthlyConsumption', e.target.value)}
                    placeholder="Ex: 400"
                    className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none"
                  />
                  <p className="mt-2 text-sm text-gray-500">
                    💡 Vous pouvez trouver cette information sur votre facture STEG
                  </p>
                </div>

                <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-900">
                    <strong>💡 Astuce:</strong> La consommation moyenne d'une maison tunisienne 
                    est d'environ 300-500 kWh/mois
                  </p>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8 pt-6 border-t">
              {step > 1 && (
                <button
                  onClick={() => setStep(step - 1)}
                  className="px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition"
                >
                  ← Retour
                </button>
              )}
              
              {step < 3 ? (
                <button
                  onClick={() => setStep(step + 1)}
                  disabled={!isStepValid()}
                  className="ml-auto px-6 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Suivant →
                </button>
              ) : (
                <button
                  onClick={handleSubmit}
                  disabled={!isStepValid()}
                  className="ml-auto px-8 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed font-bold"
                >
                  🎯 Calculer Mon Devis
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
