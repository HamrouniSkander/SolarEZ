import { useState } from 'react';
import { X, Mail, Lock, User, Building, MapPin, AlertCircle, CheckCircle } from 'lucide-react';
import { useAuth, UserRole } from '../context/AuthContext';

interface RegisterProps {
  onClose: () => void;
  onSwitchToLogin: () => void;
}

export function Register({ onClose, onSwitchToLogin }: RegisterProps) {
  const { register } = useAuth();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'particulier' as UserRole,
    company: '',
    location: ''
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const roles = [
    { value: 'particulier', label: 'Particulier / Entreprise', icon: '👤', description: 'Je veux installer des panneaux solaires' },
    { value: 'installateur', label: 'Installateur', icon: '🔧', description: 'Je suis un professionnel de l\'installation' },
    { value: 'formation', label: 'Centre de Formation', icon: '🎓', description: 'Je propose des formations photovoltaïques' },
    { value: 'fournisseur', label: 'Fournisseur', icon: '📦', description: 'Je vends du matériel photovoltaïque' }
  ];

  const tunisianCities = [
    'Tunis', 'Sfax', 'Sousse', 'Kairouan', 'Bizerte', 'Gabès', 'Ariana',
    'Gafsa', 'Monastir', 'Ben Arous', 'Kasserine', 'Médenine', 'Nabeul',
    'Tataouine', 'Béja', 'Jendouba', 'Mahdia', 'Siliana', 'Kébili',
    'Zaghouan', 'Manouba', 'Sidi Bouzid', 'Tozeur', 'Le Kef'
  ];

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Validation
    if (!formData.name || !formData.email || !formData.password || !formData.location) {
      setError('Veuillez remplir tous les champs obligatoires');
      return;
    }

    if (formData.password.length < 6) {
      setError('Le mot de passe doit contenir au moins 6 caractères');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Les mots de passe ne correspondent pas');
      return;
    }

    if ((formData.role !== 'particulier') && !formData.company) {
      setError('Le nom de l\'entreprise est requis pour ce type de compte');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('Veuillez entrer une adresse email valide');
      return;
    }

    // Register user
    const successRegister = register(formData);
    
    if (successRegister) {
      setSuccess(true);
      setTimeout(() => {
        onClose();
      }, 2000);
    } else {
      setError('Une erreur est survenue lors de l\'inscription');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-blue-600 p-6 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition"
          >
            <X size={20} />
          </button>
          <h2 className="text-2xl font-bold mb-2">Créer un Compte</h2>
          <p className="text-green-100">Rejoignez l'écosystème SolarEZ</p>
        </div>

        <div className="p-6">
          {/* Success Message */}
          {success && (
            <div className="mb-4 p-4 bg-green-50 border-2 border-green-200 rounded-lg flex items-center text-green-700">
              <CheckCircle size={20} className="mr-2 flex-shrink-0" />
              <span>Compte créé avec succès ! Redirection...</span>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border-2 border-red-200 rounded-lg flex items-center text-red-700">
              <AlertCircle size={20} className="mr-2 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Registration Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Role Selection */}
            <div>
              <label className="text-gray-700 font-medium mb-3 block">
                Type de compte *
              </label>
              <div className="grid grid-cols-2 gap-3">
                {roles.map((role) => (
                  <button
                    key={role.value}
                    type="button"
                    onClick={() => updateFormData('role', role.value)}
                    className={`p-4 rounded-lg border-2 transition text-left ${
                      formData.role === role.value
                        ? 'border-green-500 bg-green-50'
                        : 'border-gray-200 hover:border-green-300'
                    }`}
                  >
                    <div className="flex items-center mb-2">
                      <span className="text-2xl mr-2">{role.icon}</span>
                      <span className="font-bold text-gray-900">{role.label}</span>
                    </div>
                    <p className="text-xs text-gray-600">{role.description}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Name */}
            <div>
              <label className="flex items-center text-gray-700 mb-2">
                <User size={18} className="mr-2 text-green-600" />
                {formData.role === 'particulier' ? 'Nom complet' : 'Nom du responsable'} *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => updateFormData('name', e.target.value)}
                placeholder="Ex: Mohamed Ben Ali"
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none"
              />
            </div>

            {/* Company (if not particulier) */}
            {formData.role !== 'particulier' && (
              <div>
                <label className="flex items-center text-gray-700 mb-2">
                  <Building size={18} className="mr-2 text-green-600" />
                  Nom de l'entreprise *
                </label>
                <input
                  type="text"
                  value={formData.company}
                  onChange={(e) => updateFormData('company', e.target.value)}
                  placeholder="Ex: SolarPro Tunisia"
                  className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none"
                />
              </div>
            )}

            {/* Email */}
            <div>
              <label className="flex items-center text-gray-700 mb-2">
                <Mail size={18} className="mr-2 text-green-600" />
                Email *
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => updateFormData('email', e.target.value)}
                placeholder="exemple@email.com"
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none"
              />
            </div>

            {/* Location */}
            <div>
              <label className="flex items-center text-gray-700 mb-2">
                <MapPin size={18} className="mr-2 text-green-600" />
                Ville *
              </label>
              <select
                value={formData.location}
                onChange={(e) => updateFormData('location', e.target.value)}
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none"
              >
                <option value="">Sélectionnez votre ville</option>
                {tunisianCities.map((city) => (
                  <option key={city} value={city}>{city}</option>
                ))}
              </select>
            </div>

            {/* Password */}
            <div>
              <label className="flex items-center text-gray-700 mb-2">
                <Lock size={18} className="mr-2 text-green-600" />
                Mot de passe *
              </label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => updateFormData('password', e.target.value)}
                placeholder="Minimum 6 caractères"
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none"
              />
            </div>

            {/* Confirm Password */}
            <div>
              <label className="flex items-center text-gray-700 mb-2">
                <Lock size={18} className="mr-2 text-green-600" />
                Confirmer le mot de passe *
              </label>
              <input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => updateFormData('confirmPassword', e.target.value)}
                placeholder="Retapez votre mot de passe"
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none"
              />
            </div>

            {/* Terms */}
            <div className="flex items-start">
              <input type="checkbox" required className="mt-1 mr-2" />
              <label className="text-sm text-gray-600">
                J'accepte les{' '}
                <a href="#" className="text-green-600 hover:text-green-700">
                  conditions d'utilisation
                </a>{' '}
                et la{' '}
                <a href="#" className="text-green-600 hover:text-green-700">
                  politique de confidentialité
                </a>
              </label>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={success}
              className="w-full py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition font-bold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {success ? '✓ Compte créé' : 'Créer mon compte'}
            </button>
          </form>

          {/* Login Link */}
          <div className="text-center pt-4 border-t mt-6">
            <p className="text-gray-600">
              Vous avez déjà un compte ?{' '}
              <button
                onClick={onSwitchToLogin}
                className="text-green-600 hover:text-green-700 font-bold"
              >
                Se connecter
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
