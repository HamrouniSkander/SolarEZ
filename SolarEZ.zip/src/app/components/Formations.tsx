import { GraduationCap, Clock, Users, Award, Calendar, BookOpen } from 'lucide-react';

export function Formations() {
  const formations = [
    {
      id: 1,
      title: 'Installation Photovoltaïque - Niveau Débutant',
      center: 'Centre National des Énergies Renouvelables',
      location: 'Tunis',
      duration: '5 jours',
      price: 850,
      students: 245,
      rating: 4.8,
      certificate: true,
      type: 'Présentiel',
      nextSession: '15 Fév 2026',
      image: '🔧',
      topics: ['Installation panneaux', 'Câblage électrique', 'Sécurité chantier', 'Mise en service'],
      level: 'Débutant'
    },
    {
      id: 2,
      title: 'Maintenance et Dépannage Systèmes Solaires',
      center: 'EcoTech Formation',
      location: 'Sfax',
      duration: '3 jours',
      price: 650,
      students: 178,
      rating: 4.7,
      certificate: true,
      type: 'Présentiel',
      nextSession: '22 Fév 2026',
      image: '🛠️',
      topics: ['Diagnostic pannes', 'Réparation onduleurs', 'Tests performance', 'Maintenance préventive'],
      level: 'Intermédiaire'
    },
    {
      id: 3,
      title: 'Conception et Dimensionnement - Formation Avancée',
      center: 'Institut Supérieur Solaire',
      location: 'Sousse',
      duration: '7 jours',
      price: 1200,
      students: 156,
      rating: 4.9,
      certificate: true,
      type: 'Présentiel + En ligne',
      nextSession: '1 Mar 2026',
      image: '📐',
      topics: ['Calculs avancés', 'Logiciels PVsyst', 'Optimisation systèmes', 'Études de rentabilité'],
      level: 'Avancé'
    },
    {
      id: 4,
      title: 'Électricité Solaire pour Particuliers',
      center: 'SolarAcademy Tunisia',
      location: 'En ligne',
      duration: '2 semaines',
      price: 450,
      students: 421,
      rating: 4.6,
      certificate: true,
      type: 'En ligne',
      nextSession: 'Début immédiat',
      image: '💡',
      topics: ['Bases photovoltaïque', 'Composants système', 'Installation simple', 'ROI et économies'],
      level: 'Débutant'
    },
    {
      id: 5,
      title: 'Systèmes de Stockage et Batteries',
      center: 'PowerTech Institute',
      location: 'Monastir',
      duration: '4 jours',
      price: 750,
      students: 132,
      rating: 4.8,
      certificate: true,
      type: 'Présentiel',
      nextSession: '10 Mar 2026',
      image: '🔋',
      topics: ['Technologies batteries', 'Dimensionnement stockage', 'Systèmes hybrides', 'Gestion BMS'],
      level: 'Intermédiaire'
    },
    {
      id: 6,
      title: 'Business Solaire et Entrepreneuriat',
      center: 'Green Business School',
      location: 'Tunis',
      duration: '3 jours',
      price: 950,
      students: 98,
      rating: 4.7,
      certificate: true,
      type: 'Présentiel',
      nextSession: '18 Mar 2026',
      image: '💼',
      topics: ['Création entreprise', 'Prospection clients', 'Devis commerciaux', 'Réglementations ANME'],
      level: 'Tous niveaux'
    },
  ];

  return (
    <section className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Formations Photovoltaïques
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Développez vos compétences dans l'énergie solaire avec nos formations certifiées
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
          {[
            { icon: GraduationCap, label: 'Formations', value: '25+' },
            { icon: Users, label: 'Étudiants formés', value: '3,500+' },
            { icon: Award, label: 'Certifications', value: '100%' },
            { icon: BookOpen, label: 'Centres partenaires', value: '12' },
          ].map((stat, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-md text-center">
              <stat.icon className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="grid md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Niveau</label>
              <select className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none">
                <option>Tous niveaux</option>
                <option>Débutant</option>
                <option>Intermédiaire</option>
                <option>Avancé</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Type</label>
              <select className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none">
                <option>Tous types</option>
                <option>Présentiel</option>
                <option>En ligne</option>
                <option>Hybride</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Localisation</label>
              <select className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none">
                <option>Toutes villes</option>
                <option>Tunis</option>
                <option>Sfax</option>
                <option>Sousse</option>
                <option>En ligne</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Budget max (TND)</label>
              <select className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none">
                <option>Tous budgets</option>
                <option>Moins de 500</option>
                <option>500 - 800</option>
                <option>800 - 1200</option>
                <option>Plus de 1200</option>
              </select>
            </div>
          </div>
        </div>

        {/* Formations Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {formations.map((formation) => (
            <div key={formation.id} className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition overflow-hidden flex flex-col">
              <div className="bg-gradient-to-br from-green-500 to-blue-500 p-6 text-white">
                <div className="text-5xl mb-3">{formation.image}</div>
                <h3 className="text-xl font-bold mb-2">{formation.title}</h3>
                <div className="text-sm text-green-100">{formation.center}</div>
              </div>

              <div className="p-6 flex-1 flex flex-col">
                <div className="space-y-3 mb-4">
                  <div className="flex items-center text-gray-600">
                    <Clock size={16} className="mr-2 text-green-600" />
                    <span className="text-sm">{formation.duration}</span>
                    <span className="mx-2">•</span>
                    <span className="text-sm">{formation.type}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <Calendar size={16} className="mr-2 text-green-600" />
                    <span className="text-sm">{formation.nextSession}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-gray-600">
                      <Users size={16} className="mr-2 text-green-600" />
                      <span className="text-sm">{formation.students} formés</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-yellow-400 mr-1">⭐</span>
                      <span className="font-bold text-gray-900">{formation.rating}</span>
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="text-sm font-medium text-gray-700 mb-2">Programme</div>
                  <div className="space-y-1">
                    {formation.topics.map((topic, index) => (
                      <div key={index} className="flex items-start text-sm text-gray-600">
                        <span className="text-green-600 mr-2">✓</span>
                        <span>{topic}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    formation.level === 'Débutant' ? 'bg-green-100 text-green-700' :
                    formation.level === 'Intermédiaire' ? 'bg-blue-100 text-blue-700' :
                    formation.level === 'Avancé' ? 'bg-purple-100 text-purple-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {formation.level}
                  </span>
                  {formation.certificate && (
                    <span className="flex items-center text-sm text-green-600">
                      <Award size={16} className="mr-1" />
                      Certifié
                    </span>
                  )}
                </div>

                <div className="mt-auto pt-4 border-t">
                  <div className="flex items-end justify-between mb-3">
                    <div>
                      <div className="text-sm text-gray-600">Prix</div>
                      <div className="text-2xl font-bold text-gray-900">{formation.price} TND</div>
                    </div>
                  </div>
                  <button className="w-full py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition font-bold">
                    S'inscrire
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA for Training Centers */}
        <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-8 text-center text-white">
          <h3 className="text-2xl font-bold mb-4">Vous êtes un centre de formation ?</h3>
          <p className="text-lg text-purple-100 mb-6">
            Publiez vos formations sur SolarEZ et touchez des milliers de professionnels
          </p>
          <button className="px-8 py-3 bg-white text-purple-600 rounded-lg hover:shadow-2xl transition font-bold">
            Devenir Centre Partenaire
          </button>
        </div>
      </div>
    </section>
  );
}
