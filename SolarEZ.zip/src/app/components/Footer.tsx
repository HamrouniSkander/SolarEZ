import { Mail, Phone, MapPin, Facebook, Linkedin, Instagram } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* About */}
          <div>
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
                <span className="text-2xl">☀️</span>
              </div>
              <span className="ml-3 text-xl font-bold">SolarEZ</span>
            </div>
            <p className="text-gray-400 mb-4">
              La plateforme N°1 du photovoltaïque en Tunisie. Simplifiez votre transition énergétique.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-green-600 transition">
                <Facebook size={20} />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-green-600 transition">
                <Linkedin size={20} />
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-green-600 transition">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-lg mb-4">Liens Rapides</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">Accueil</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">Simulation Gratuite</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">Installateurs</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">Formations</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">Emploi</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">À Propos</a></li>
            </ul>
          </div>

          {/* For Professionals */}
          <div>
            <h4 className="font-bold text-lg mb-4">Professionnels</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">Devenir Installateur</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">Espace Fournisseur</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">Centre de Formation</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">Publier une Offre</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">Publicité</a></li>
              <li><a href="#" className="text-gray-400 hover:text-green-400 transition">API & Partenariats</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-lg mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin size={20} className="mr-2 text-green-400 flex-shrink-0 mt-1" />
                <span className="text-gray-400">Avenue Habib Bourguiba, Tunis, Tunisie</span>
              </li>
              <li className="flex items-center">
                <Phone size={20} className="mr-2 text-green-400" />
                <a href="tel:+21671234567" className="text-gray-400 hover:text-green-400 transition">
                  +216 71 234 567
                </a>
              </li>
              <li className="flex items-center">
                <Mail size={20} className="mr-2 text-green-400" />
                <a href="mailto:contact@solarez.tn" className="text-gray-400 hover:text-green-400 transition">
                  contact@solarez.tn
                </a>
              </li>
            </ul>
            <div className="mt-6 p-4 bg-gray-800 rounded-lg">
              <p className="text-sm text-gray-400 mb-2">Newsletter</p>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Email"
                  className="flex-1 px-3 py-2 bg-gray-700 text-white rounded-l-lg focus:outline-none text-sm"
                />
                <button className="px-4 py-2 bg-green-600 rounded-r-lg hover:bg-green-700 transition text-sm">
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2026 SolarEZ. Tous droits réservés.
            </p>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-green-400 transition">Conditions d'utilisation</a>
              <a href="#" className="text-gray-400 hover:text-green-400 transition">Politique de confidentialité</a>
              <a href="#" className="text-gray-400 hover:text-green-400 transition">Mentions légales</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
