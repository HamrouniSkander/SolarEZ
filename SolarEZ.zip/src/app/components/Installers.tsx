import { Star, MapPin, Phone, Mail, Award, Wrench } from 'lucide-react';

export function Installers() {
  const installers = [
    {
      id: 1,
      name: 'SunPower Tunisia',
      location: 'Tunis',
      rating: 4.9,
      reviews: 127,
      projects: 450,
      certifications: ['ANME', 'ISO 9001'],
      specialties: ['Résidentiel', 'Commercial'],
      image: '🏢',
      description: 'Leader en installation photovoltaïque depuis 2015',
      response: '< 2h'
    },
    {
      id: 2,
      name: 'EcoSolar Sfax',
      location: 'Sfax',
      rating: 4.8,
      reviews: 93,
      projects: 320,
      certifications: ['ANME', 'Certified Installer'],
      specialties: ['Résidentiel', 'PME'],
      image: '⚡',
      description: 'Spécialiste de l\'installation pour entreprises',
      response: '< 3h'
    },
    {
      id: 3,
      name: 'Photon Energy',
      location: 'Sousse',
      rating: 4.7,
      reviews: 85,
      projects: 280,
      certifications: ['ANME'],
      specialties: ['Résidentiel', 'Agricole'],
      image: '☀️',
      description: 'Expert en solutions agricoles et résidentielles',
      response: '< 4h'
    },
    {
      id: 4,
      name: 'Green Energy Solutions',
      location: 'Monastir',
      rating: 4.9,
      reviews: 112,
      projects: 390,
      certifications: ['ANME', 'ISO 9001', 'PV Installer'],
      specialties: ['Résidentiel', 'Commercial', 'Industriel'],
      image: '🌱',
      description: 'Solutions complètes pour tous types de projets',
      response: '< 1h'
    },
    {
      id: 5,
      name: 'Solar Tech Nabeul',
      location: 'Nabeul',
      rating: 4.6,
      reviews: 68,
      projects: 195,
      certifications: ['ANME'],
      specialties: ['Résidentiel'],
      image: '🔆',
      description: 'Spécialiste installations résidentielles de qualité',
      response: '< 3h'
    },
    {
      id: 6,
      name: 'Renewable Power Bizerte',
      location: 'Bizerte',
      rating: 4.8,
      reviews: 91,
      projects: 245,
      certifications: ['ANME', 'ISO 14001'],
      specialties: ['Résidentiel', 'PME'],
      image: '🌍',
      description: 'Engagement environnemental et qualité certifiée',
      response: '< 2h'
    },
  ];

  return (
    <section className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Installateurs Certifiés
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Réseau d'installateurs photovoltaïques qualifiés et vérifiés partout en Tunisie
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="grid md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Région</label>
              <select className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none">
                <option>Toutes les régions</option>
                <option>Tunis</option>
                <option>Sfax</option>
                <option>Sousse</option>
                <option>Monastir</option>
                <option>Nabeul</option>
                <option>Bizerte</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Spécialité</label>
              <select className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none">
                <option>Toutes spécialités</option>
                <option>Résidentiel</option>
                <option>Commercial</option>
                <option>Industriel</option>
                <option>Agricole</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Certification</label>
              <select className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none">
                <option>Toutes certifications</option>
                <option>ANME</option>
                <option>ISO 9001</option>
                <option>PV Installer</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Note minimum</label>
              <select className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none">
                <option>Toutes notes</option>
                <option>⭐ 4.5+</option>
                <option>⭐ 4.0+</option>
                <option>⭐ 3.5+</option>
              </select>
            </div>
          </div>
        </div>

        {/* Installers Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {installers.map((installer) => (
            <div key={installer.id} className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition overflow-hidden">
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center">
                    <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-blue-500 rounded-xl flex items-center justify-center text-3xl mr-4">
                      {installer.image}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{installer.name}</h3>
                      <div className="flex items-center text-gray-600 mt-1">
                        <MapPin size={16} className="mr-1" />
                        <span>{installer.location}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center mb-1">
                      <Star size={20} className="text-yellow-400 fill-current mr-1" />
                      <span className="text-xl font-bold text-gray-900">{installer.rating}</span>
                    </div>
                    <div className="text-sm text-gray-600">{installer.reviews} avis</div>
                  </div>
                </div>

                <p className="text-gray-600 mb-4">{installer.description}</p>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <div className="flex items-center text-blue-600 mb-1">
                      <Wrench size={16} className="mr-1" />
                      <span className="text-sm font-medium">Projets</span>
                    </div>
                    <div className="text-xl font-bold text-gray-900">{installer.projects}</div>
                  </div>
                  <div className="bg-green-50 p-3 rounded-lg">
                    <div className="flex items-center text-green-600 mb-1">
                      <Award size={16} className="mr-1" />
                      <span className="text-sm font-medium">Réponse</span>
                    </div>
                    <div className="text-xl font-bold text-gray-900">{installer.response}</div>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="text-sm font-medium text-gray-700 mb-2">Certifications</div>
                  <div className="flex flex-wrap gap-2">
                    {installer.certifications.map((cert) => (
                      <span key={cert} className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                        ✓ {cert}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mb-4">
                  <div className="text-sm font-medium text-gray-700 mb-2">Spécialités</div>
                  <div className="flex flex-wrap gap-2">
                    {installer.specialties.map((specialty) => (
                      <span key={specialty} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-4 border-t">
                  <button className="flex items-center justify-center px-4 py-3 border-2 border-green-500 text-green-600 rounded-lg hover:bg-green-50 transition">
                    <Phone size={18} className="mr-2" />
                    Appeler
                  </button>
                  <button className="flex items-center justify-center px-4 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition">
                    <Mail size={18} className="mr-2" />
                    Demander un Devis
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA for Installers */}
        <div className="mt-12 bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-center text-white">
          <h3 className="text-2xl font-bold mb-4">Vous êtes installateur ?</h3>
          <p className="text-lg text-blue-100 mb-6">
            Rejoignez SolarEZ et accédez à des leads qualifiés partout en Tunisie
          </p>
          <button className="px-8 py-3 bg-white text-blue-600 rounded-lg hover:shadow-2xl transition font-bold">
            Devenir Partenaire Installateur
          </button>
        </div>
      </div>
    </section>
  );
}
