import { SimulationResult } from '../App';
import { Download, Phone, TrendingUp, Zap, Sun, Leaf, Calendar, DollarSign } from 'lucide-react';

interface QuoteResultProps {
  result: SimulationResult;
  onBack: () => void;
  onContactInstaller: () => void;
}

export function QuoteResult({ result, onBack, onContactInstaller }: QuoteResultProps) {
  const totalEconomies25Years = result.annualEconomies * 25;
  const profitAfterROI = totalEconomies25Years - result.totalCost;
  const monthlyProduction = Math.round(result.annualProduction / 12);

  const handleDownloadPDF = () => {
    alert('Génération du devis PDF... (Fonctionnalité à implémenter)');
  };

  return (
    <section className="py-12 min-h-screen">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Success Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-4">
            <span className="text-4xl">✅</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Votre Devis Solaire Personnalisé
          </h1>
          <p className="text-xl text-gray-600">
            Analyse complète de votre installation photovoltaïque
          </p>
        </div>

        {/* Main Results Card */}
        <div className="bg-gradient-to-br from-green-600 to-blue-600 rounded-2xl shadow-2xl p-8 text-white mb-8">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-5xl font-bold mb-2">{result.powerKWc} kWc</div>
              <div className="text-green-100">Puissance Système</div>
              <div className="text-sm mt-1">{result.numPanels} panneaux de 400W</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold mb-2">{result.totalCost.toLocaleString()} TND</div>
              <div className="text-green-100">Investissement Total</div>
              <div className="text-sm mt-1">Matériel + Installation</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold mb-2">{result.roi} ans</div>
              <div className="text-green-100">Retour sur Investissement</div>
              <div className="text-sm mt-1">Puis 17+ ans d'énergie gratuite</div>
            </div>
          </div>
        </div>

        {/* Detailed Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Monthly Economics */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <DollarSign className="text-green-600" size={24} />
              </div>
              <h3 className="ml-3 text-xl font-bold text-gray-900">Économies Mensuelles</h3>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Production mensuelle</span>
                <span className="font-bold text-gray-900">{monthlyProduction} kWh</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Consommation actuelle</span>
                <span className="font-bold text-gray-900">{Math.round(result.monthlyConsumption)} kWh</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Économies mensuelles</span>
                <span className="font-bold text-green-600 text-xl">{result.monthlyEconomies} TND</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-gray-600">Économies annuelles</span>
                <span className="font-bold text-green-600 text-xl">{result.annualEconomies} TND</span>
              </div>
            </div>
          </div>

          {/* Production Details */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Sun className="text-yellow-600" size={24} />
              </div>
              <h3 className="ml-3 text-xl font-bold text-gray-900">Production Solaire</h3>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Région</span>
                <span className="font-bold text-gray-900">{result.region}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Orientation</span>
                <span className="font-bold text-gray-900">{result.orientation}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Type de toit</span>
                <span className="font-bold text-gray-900">{result.roofType}</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-gray-600">Production annuelle</span>
                <span className="font-bold text-yellow-600 text-xl">{result.annualProduction.toLocaleString()} kWh</span>
              </div>
            </div>
          </div>

          {/* 25-Year Projection */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="text-blue-600" size={24} />
              </div>
              <h3 className="ml-3 text-xl font-bold text-gray-900">Projection 25 ans</h3>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Investissement initial</span>
                <span className="font-bold text-red-600">-{result.totalCost.toLocaleString()} TND</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Économies totales</span>
                <span className="font-bold text-green-600">+{totalEconomies25Years.toLocaleString()} TND</span>
              </div>
              <div className="flex justify-between items-center py-2 bg-green-50 -mx-6 px-6">
                <span className="font-bold text-gray-900">Bénéfice net</span>
                <span className="font-bold text-green-600 text-2xl">+{profitAfterROI.toLocaleString()} TND</span>
              </div>
            </div>
            <div className="mt-4 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-900">
                <strong>💰 Rentabilité garantie:</strong> Système amorti en {result.roi} ans, 
                puis énergie quasi gratuite pendant {Math.round(25 - result.roi)} ans
              </p>
            </div>
          </div>

          {/* Environmental Impact */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Leaf className="text-green-600" size={24} />
              </div>
              <h3 className="ml-3 text-xl font-bold text-gray-900">Impact Environnemental</h3>
            </div>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-600">CO₂ évité par an</span>
                  <span className="font-bold text-green-600">{result.co2Reduction.toLocaleString()} kg</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: '100%' }}></div>
                </div>
              </div>
              <div className="flex items-center justify-around p-4 bg-green-50 rounded-lg">
                <div className="text-center">
                  <div className="text-3xl mb-1">🌳</div>
                  <div className="font-bold text-gray-900">{Math.round(result.co2Reduction / 21)}</div>
                  <div className="text-xs text-gray-600">Arbres équivalents</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl mb-1">🚗</div>
                  <div className="font-bold text-gray-900">{Math.round(result.co2Reduction / 120)}</div>
                  <div className="text-xs text-gray-600">km en voiture évités</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl mb-1">🏠</div>
                  <div className="font-bold text-gray-900">{Math.round(result.annualProduction / 12)}</div>
                  <div className="text-xs text-gray-600">Foyers alimentés/mois</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* System Details */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Détails du Système</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <div className="text-sm text-gray-600 mb-1">Configuration</div>
              <div className="font-bold text-gray-900">{result.numPanels} panneaux photovoltaïques</div>
              <div className="text-sm text-gray-500">400W chacun (technologie monocristallin)</div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-1">Onduleur</div>
              <div className="font-bold text-gray-900">Onduleur {result.powerKWc} kW</div>
              <div className="text-sm text-gray-500">Garantie 10 ans</div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-1">Structure</div>
              <div className="font-bold text-gray-900">Support {result.roofType.toLowerCase()}</div>
              <div className="text-sm text-gray-500">Aluminium anticorrosion</div>
            </div>
          </div>
          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-700">
              <strong>Garanties:</strong> Panneaux 25 ans • Onduleur 10 ans • Installation 5 ans
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <button
            onClick={handleDownloadPDF}
            className="flex items-center justify-center px-6 py-4 bg-white border-2 border-gray-300 rounded-lg hover:shadow-lg transition"
          >
            <Download size={20} className="mr-2" />
            Télécharger le Devis PDF
          </button>
          <button
            onClick={onContactInstaller}
            className="flex items-center justify-center px-6 py-4 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition"
          >
            <Phone size={20} className="mr-2" />
            Contacter un Installateur
          </button>
          <button
            onClick={onBack}
            className="flex items-center justify-center px-6 py-4 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition"
          >
            Nouvelle Simulation
          </button>
        </div>

        {/* Next Steps */}
        <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Prochaines Étapes</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                step: '1',
                icon: Phone,
                title: 'Choisir un Installateur',
                description: 'Comparez les installateurs certifiés et demandez une visite technique gratuite'
              },
              {
                step: '2',
                icon: Calendar,
                title: 'Planifier l\'Installation',
                description: 'Validation technique, permis et planification des travaux (2-3 semaines)'
              },
              {
                step: '3',
                icon: Zap,
                title: 'Commencer à Économiser',
                description: 'Installation en 2-3 jours, mise en service et début des économies immédiat'
              },
            ].map((item) => (
              <div key={item.step} className="bg-white rounded-lg p-6">
                <div className="flex items-center mb-3">
                  <div className="w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center font-bold mr-3">
                    {item.step}
                  </div>
                  <item.icon className="text-green-600" size={24} />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">{item.title}</h4>
                <p className="text-sm text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
