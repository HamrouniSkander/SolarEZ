import { useAuth } from '../context/AuthContext';
import { BarChart3, Users, Briefcase, Package, Settings, TrendingUp, DollarSign, Calendar, FileText, ShoppingCart } from 'lucide-react';

interface DashboardProps {
  onBack: () => void;
}

export function Dashboard({ onBack }: DashboardProps) {
  const { user } = useAuth();

  if (!user) return null;

  // Dashboard content based on user role
  const renderDashboard = () => {
    switch (user.role) {
      case 'particulier':
        return <ParticulierDashboard user={user} />;
      case 'installateur':
        return <InstallateurDashboard user={user} />;
      case 'formation':
        return <FormationDashboard user={user} />;
      case 'fournisseur':
        return <FournisseurDashboard user={user} />;
      case 'admin':
        return <AdminDashboard user={user} />;
      default:
        return null;
    }
  };

  return (
    <section className="py-12 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="text-green-600 hover:text-green-700 mb-4 flex items-center"
          >
            ← Retour à l'accueil
          </button>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Tableau de Bord
              </h1>
              <p className="text-gray-600">
                Bienvenue, {user.name}
              </p>
            </div>
            <div className="text-5xl">{user.avatar}</div>
          </div>
        </div>

        {renderDashboard()}
      </div>
    </section>
  );
}

// Particulier Dashboard
function ParticulierDashboard({ user }: { user: any }) {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <FileText className="text-blue-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">3</span>
          </div>
          <div className="text-sm text-gray-600">Simulations réalisées</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <Calendar className="text-green-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">1</span>
          </div>
          <div className="text-sm text-gray-600">Devis en attente</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <Users className="text-purple-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">5</span>
          </div>
          <div className="text-sm text-gray-600">Installateurs contactés</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="text-yellow-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">11,200</span>
          </div>
          <div className="text-sm text-gray-600">Budget estimé (TND)</div>
        </div>
      </div>

      {/* Recent Simulations */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Mes Simulations Récentes</h3>
        <div className="space-y-3">
          {[
            { date: '3 Jan 2026', power: '3.2 kWc', cost: '11,200 TND', status: 'Complété' },
            { date: '28 Déc 2025', power: '5.0 kWc', cost: '17,500 TND', status: 'Devis demandé' },
            { date: '15 Déc 2025', power: '2.8 kWc', cost: '9,800 TND', status: 'Brouillon' },
          ].map((sim, index) => (
            <div key={index} className="flex items-center justify-between p-4 border-2 border-gray-100 rounded-lg hover:border-green-200 transition">
              <div>
                <div className="font-bold text-gray-900">{sim.power} - {sim.cost}</div>
                <div className="text-sm text-gray-600">{sim.date}</div>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm ${
                sim.status === 'Complété' ? 'bg-green-100 text-green-700' :
                sim.status === 'Devis demandé' ? 'bg-blue-100 text-blue-700' :
                'bg-gray-100 text-gray-700'
              }`}>
                {sim.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-6">
        <button className="p-6 bg-gradient-to-br from-green-50 to-blue-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">🧮</div>
          <h4 className="font-bold text-gray-900 mb-2">Nouvelle Simulation</h4>
          <p className="text-sm text-gray-600">Calculez votre potentiel solaire</p>
        </button>
        <button className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">🎓</div>
          <h4 className="font-bold text-gray-900 mb-2">Formations Disponibles</h4>
          <p className="text-sm text-gray-600">Apprenez-en plus sur le solaire</p>
        </button>
        <button className="p-6 bg-gradient-to-br from-orange-50 to-red-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">💼</div>
          <h4 className="font-bold text-gray-900 mb-2">Offres d'Emploi</h4>
          <p className="text-sm text-gray-600">Découvrez les opportunités</p>
        </button>
      </div>
    </div>
  );
}

// Installateur Dashboard
function InstallateurDashboard({ user }: { user: any }) {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <Users className="text-blue-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">23</span>
          </div>
          <div className="text-sm text-gray-600">Nouveaux leads ce mois</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <FileText className="text-green-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">12</span>
          </div>
          <div className="text-sm text-gray-600">Devis en attente</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="text-purple-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">8</span>
          </div>
          <div className="text-sm text-gray-600">Projets en cours</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="text-yellow-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">245K</span>
          </div>
          <div className="text-sm text-gray-600">CA du mois (TND)</div>
        </div>
      </div>

      {/* Recent Leads */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Leads Récents</h3>
        <div className="space-y-3">
          {[
            { name: 'Ahmed Trabelsi', location: 'Tunis', power: '3.2 kWc', budget: '11,200 TND', date: 'Aujourd\'hui', urgent: true },
            { name: 'Salma Kacem', location: 'Ariana', power: '5.0 kWc', budget: '17,500 TND', date: 'Hier', urgent: false },
            { name: 'Hichem Ben', location: 'Ben Arous', power: '4.5 kWc', budget: '15,750 TND', date: 'Il y a 2 jours', urgent: false },
          ].map((lead, index) => (
            <div key={index} className="flex items-center justify-between p-4 border-2 border-gray-100 rounded-lg hover:border-green-200 transition">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <div className="font-bold text-gray-900">{lead.name}</div>
                  {lead.urgent && <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs">🔥 Urgent</span>}
                </div>
                <div className="text-sm text-gray-600">📍 {lead.location} • {lead.power} • {lead.budget}</div>
                <div className="text-xs text-gray-500">{lead.date}</div>
              </div>
              <button className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition">
                Voir le lead
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-6">
        <button className="p-6 bg-gradient-to-br from-green-50 to-blue-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">📝</div>
          <h4 className="font-bold text-gray-900 mb-2">Créer un Devis</h4>
          <p className="text-sm text-gray-600">Générez rapidement un devis</p>
        </button>
        <button className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">📦</div>
          <h4 className="font-bold text-gray-900 mb-2">Commander Matériel</h4>
          <p className="text-sm text-gray-600">Accédez aux fournisseurs</p>
        </button>
        <button className="p-6 bg-gradient-to-br from-orange-50 to-red-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">👥</div>
          <h4 className="font-bold text-gray-900 mb-2">Recrutement</h4>
          <p className="text-sm text-gray-600">Publiez une offre d'emploi</p>
        </button>
      </div>
    </div>
  );
}

// Formation Dashboard
function FormationDashboard({ user }: { user: any }) {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <Briefcase className="text-blue-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">12</span>
          </div>
          <div className="text-sm text-gray-600">Formations actives</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <Users className="text-green-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">156</span>
          </div>
          <div className="text-sm text-gray-600">Étudiants inscrits</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <Calendar className="text-purple-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">8</span>
          </div>
          <div className="text-sm text-gray-600">Sessions ce mois</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="text-yellow-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">38K</span>
          </div>
          <div className="text-sm text-gray-600">Revenus du mois (TND)</div>
        </div>
      </div>

      {/* Upcoming Sessions */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Prochaines Sessions</h3>
        <div className="space-y-3">
          {[
            { title: 'Installation Photovoltaïque', date: '15 Fév 2026', students: 18, capacity: 20 },
            { title: 'Maintenance Systèmes Solaires', date: '22 Fév 2026', students: 12, capacity: 15 },
            { title: 'Conception Avancée', date: '1 Mar 2026', students: 8, capacity: 12 },
          ].map((session, index) => (
            <div key={index} className="flex items-center justify-between p-4 border-2 border-gray-100 rounded-lg">
              <div>
                <div className="font-bold text-gray-900">{session.title}</div>
                <div className="text-sm text-gray-600">📅 {session.date}</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-gray-900">{session.students}/{session.capacity}</div>
                <div className="text-xs text-gray-600">Inscrits</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-6">
        <button className="p-6 bg-gradient-to-br from-green-50 to-blue-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">➕</div>
          <h4 className="font-bold text-gray-900 mb-2">Nouvelle Formation</h4>
          <p className="text-sm text-gray-600">Créez un nouveau programme</p>
        </button>
        <button className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">👥</div>
          <h4 className="font-bold text-gray-900 mb-2">Gérer les Étudiants</h4>
          <p className="text-sm text-gray-600">Inscriptions et présences</p>
        </button>
        <button className="p-6 bg-gradient-to-br from-orange-50 to-red-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">📊</div>
          <h4 className="font-bold text-gray-900 mb-2">Statistiques</h4>
          <p className="text-sm text-gray-600">Analysez vos performances</p>
        </button>
      </div>
    </div>
  );
}

// Fournisseur Dashboard
function FournisseurDashboard({ user }: { user: any }) {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <Package className="text-blue-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">245</span>
          </div>
          <div className="text-sm text-gray-600">Produits au catalogue</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <ShoppingCart className="text-green-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">34</span>
          </div>
          <div className="text-sm text-gray-600">Commandes ce mois</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <Users className="text-purple-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">67</span>
          </div>
          <div className="text-sm text-gray-600">Clients actifs</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="text-yellow-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">189K</span>
          </div>
          <div className="text-sm text-gray-600">CA du mois (TND)</div>
        </div>
      </div>

      {/* Recent Orders */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Commandes Récentes</h3>
        <div className="space-y-3">
          {[
            { client: 'SunPower Tunisia', product: '20 Panneaux 400W', amount: '12,500 TND', status: 'En préparation' },
            { client: 'EcoSolar Sfax', product: '5 Onduleurs 5kW', amount: '8,750 TND', status: 'Expédié' },
            { client: 'Green Energy', product: '15 Structures alu', amount: '6,200 TND', status: 'Livré' },
          ].map((order, index) => (
            <div key={index} className="flex items-center justify-between p-4 border-2 border-gray-100 rounded-lg">
              <div>
                <div className="font-bold text-gray-900">{order.client}</div>
                <div className="text-sm text-gray-600">{order.product}</div>
              </div>
              <div className="text-right">
                <div className="font-bold text-gray-900">{order.amount}</div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  order.status === 'Livré' ? 'bg-green-100 text-green-700' :
                  order.status === 'Expédié' ? 'bg-blue-100 text-blue-700' :
                  'bg-yellow-100 text-yellow-700'
                }`}>
                  {order.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-6">
        <button className="p-6 bg-gradient-to-br from-green-50 to-blue-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">📦</div>
          <h4 className="font-bold text-gray-900 mb-2">Ajouter Produit</h4>
          <p className="text-sm text-gray-600">Enrichissez votre catalogue</p>
        </button>
        <button className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">📋</div>
          <h4 className="font-bold text-gray-900 mb-2">Gérer Stock</h4>
          <p className="text-sm text-gray-600">Inventaire et disponibilités</p>
        </button>
        <button className="p-6 bg-gradient-to-br from-orange-50 to-red-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">💬</div>
          <h4 className="font-bold text-gray-900 mb-2">Messages</h4>
          <p className="text-sm text-gray-600">Communiquez avec clients</p>
        </button>
      </div>
    </div>
  );
}

// Admin Dashboard
function AdminDashboard({ user }: { user: any }) {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <Users className="text-blue-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">2,458</span>
          </div>
          <div className="text-sm text-gray-600">Utilisateurs totaux</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="text-green-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">+124</span>
          </div>
          <div className="text-sm text-gray-600">Nouveaux ce mois</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <FileText className="text-purple-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">456</span>
          </div>
          <div className="text-sm text-gray-600">Simulations ce mois</div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="text-yellow-600" size={24} />
            <span className="text-2xl font-bold text-gray-900">1.2M</span>
          </div>
          <div className="text-sm text-gray-600">Valeur projets (TND)</div>
        </div>
      </div>

      {/* Platform Activity */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Utilisateurs par Type</h3>
          <div className="space-y-3">
            {[
              { type: 'Particuliers', count: 1834, color: 'bg-blue-500' },
              { type: 'Installateurs', count: 156, color: 'bg-green-500' },
              { type: 'Centres Formation', count: 23, color: 'bg-purple-500' },
              { type: 'Fournisseurs', count: 45, color: 'bg-orange-500' },
            ].map((item, index) => (
              <div key={index}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-gray-700">{item.type}</span>
                  <span className="font-bold text-gray-900">{item.count}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className={`${item.color} h-2 rounded-full`} style={{ width: `${(item.count / 2458) * 100}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">En Attente de Validation</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <span className="text-gray-700">Nouveaux installateurs</span>
              <span className="font-bold text-yellow-600">8</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <span className="text-gray-700">Publicités en attente</span>
              <span className="font-bold text-yellow-600">12</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <span className="text-gray-700">Formations à vérifier</span>
              <span className="font-bold text-yellow-600">5</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <span className="text-gray-700">Signalements</span>
              <span className="font-bold text-yellow-600">3</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-4 gap-6">
        <button className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">👥</div>
          <h4 className="font-bold text-gray-900 mb-2">Utilisateurs</h4>
          <p className="text-sm text-gray-600">Gérer les comptes</p>
        </button>
        <button className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">✅</div>
          <h4 className="font-bold text-gray-900 mb-2">Validations</h4>
          <p className="text-sm text-gray-600">Approuver contenus</p>
        </button>
        <button className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">📊</div>
          <h4 className="font-bold text-gray-900 mb-2">Analytics</h4>
          <p className="text-sm text-gray-600">Rapports détaillés</p>
        </button>
        <button className="p-6 bg-gradient-to-br from-orange-50 to-red-50 rounded-xl hover:shadow-lg transition text-left">
          <div className="text-3xl mb-3">⚙️</div>
          <h4 className="font-bold text-gray-900 mb-2">Paramètres</h4>
          <p className="text-sm text-gray-600">Config plateforme</p>
        </button>
      </div>
    </div>
  );
}
