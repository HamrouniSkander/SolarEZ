import { useState, useRef, useEffect } from 'react';
import { User, LogOut, Settings, LayoutDashboard, ChevronDown } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface UserMenuProps {
  onDashboard: () => void;
}

export function UserMenu({ onDashboard }: UserMenuProps) {
  const { user, logout } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!user) return null;

  const getRoleBadge = () => {
    const badges = {
      'particulier': { label: 'Particulier', color: 'bg-blue-100 text-blue-700' },
      'installateur': { label: 'Installateur', color: 'bg-green-100 text-green-700' },
      'formation': { label: 'Formation', color: 'bg-purple-100 text-purple-700' },
      'fournisseur': { label: 'Fournisseur', color: 'bg-orange-100 text-orange-700' },
      'admin': { label: 'Admin', color: 'bg-yellow-100 text-yellow-700' }
    };
    return badges[user.role];
  };

  const badge = getRoleBadge();

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-3 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition"
      >
        <div className="w-8 h-8 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center text-white">
          <span className="text-lg">{user.avatar}</span>
        </div>
        <div className="hidden md:block text-left">
          <div className="font-medium text-gray-900">{user.name}</div>
          <div className={`text-xs px-2 py-0.5 ${badge.color} rounded-full inline-block`}>
            {badge.label}
          </div>
        </div>
        <ChevronDown size={16} className={`text-gray-600 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden z-50">
          {/* User Info */}
          <div className="p-4 bg-gradient-to-r from-green-50 to-blue-50 border-b">
            <div className="flex items-center mb-2">
              <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center text-white mr-3">
                <span className="text-2xl">{user.avatar}</span>
              </div>
              <div>
                <div className="font-bold text-gray-900">{user.name}</div>
                <div className="text-sm text-gray-600">{user.email}</div>
              </div>
            </div>
            {user.company && (
              <div className="text-sm text-gray-600">🏢 {user.company}</div>
            )}
            {user.location && (
              <div className="text-sm text-gray-600">📍 {user.location}</div>
            )}
          </div>

          {/* Menu Items */}
          <div className="py-2">
            <button
              onClick={() => {
                onDashboard();
                setIsOpen(false);
              }}
              className="w-full px-4 py-3 text-left hover:bg-gray-50 transition flex items-center text-gray-700"
            >
              <LayoutDashboard size={18} className="mr-3 text-green-600" />
              <span>Tableau de Bord</span>
            </button>
            <button
              onClick={() => setIsOpen(false)}
              className="w-full px-4 py-3 text-left hover:bg-gray-50 transition flex items-center text-gray-700"
            >
              <User size={18} className="mr-3 text-green-600" />
              <span>Mon Profil</span>
            </button>
            <button
              onClick={() => setIsOpen(false)}
              className="w-full px-4 py-3 text-left hover:bg-gray-50 transition flex items-center text-gray-700"
            >
              <Settings size={18} className="mr-3 text-green-600" />
              <span>Paramètres</span>
            </button>
          </div>

          {/* Logout */}
          <div className="border-t">
            <button
              onClick={() => {
                logout();
                setIsOpen(false);
              }}
              className="w-full px-4 py-3 text-left hover:bg-red-50 transition flex items-center text-red-600"
            >
              <LogOut size={18} className="mr-3" />
              <span>Déconnexion</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
