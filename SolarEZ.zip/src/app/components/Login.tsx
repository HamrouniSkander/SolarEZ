import { useState } from 'react';
import { X, Mail, Lock, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface LoginProps {
  onClose: () => void;
  onSwitchToRegister: () => void;
}

export function Login({ onClose, onSwitchToRegister }: LoginProps) {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showTestAccounts, setShowTestAccounts] = useState(false);

  const testAccounts = [
    {
      role: 'Particulier',
      email: 'karim.ben@gmail.com',
      password: 'particulier123',
      icon: '👤',
      color: 'from-blue-500 to-cyan-500'
    },
    {
      role: 'Installateur',
      email: 'contact@sunpower.tn',
      password: 'installateur123',
      icon: '🔧',
      color: 'from-green-500 to-emerald-500'
    },
    {
      role: 'Centre de Formation',
      email: 'info@solaracademy.tn',
      password: 'formation123',
      icon: '🎓',
      color: 'from-purple-500 to-pink-500'
    },
    {
      role: 'Fournisseur',
      email: 'sales@solarpro.tn',
      password: 'fournisseur123',
      icon: '📦',
      color: 'from-orange-500 to-red-500'
    },
    {
      role: 'Super Admin',
      email: 'admin@solarez.tn',
      password: 'admin123',
      icon: '👑',
      color: 'from-yellow-500 to-amber-500'
    }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Veuillez remplir tous les champs');
      return;
    }

    const success = login(email, password);
    
    if (success) {
      onClose();
    } else {
      setError('Email ou mot de passe incorrect');
    }
  };

  const handleTestAccount = (testEmail: string, testPassword: string) => {
    setEmail(testEmail);
    setPassword(testPassword);
    setError('');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-blue-600 p-6 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition"
          >
            <X size={20} />
          </button>
          <h2 className="text-2xl font-bold mb-2">Connexion</h2>
          <p className="text-green-100">Accédez à votre compte SolarEZ</p>
        </div>

        <div className="p-6">
          {/* Error Message */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 border-2 border-red-200 rounded-lg flex items-center text-red-700">
              <AlertCircle size={20} className="mr-2 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4 mb-6">
            <div>
              <label className="flex items-center text-gray-700 mb-2">
                <Mail size={18} className="mr-2 text-green-600" />
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="exemple@email.com"
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="flex items-center text-gray-700 mb-2">
                <Lock size={18} className="mr-2 text-green-600" />
                Mot de passe
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-green-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center text-gray-600">
                <input type="checkbox" className="mr-2" />
                Se souvenir de moi
              </label>
              <a href="#" className="text-green-600 hover:text-green-700">
                Mot de passe oublié ?
              </a>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition font-bold"
            >
              Se Connecter
            </button>
          </form>

          {/* Divider */}
          <div className="relative mb-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-200"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-4 bg-white text-gray-500">Ou</span>
            </div>
          </div>

          {/* Test Accounts Toggle */}
          <button
            onClick={() => setShowTestAccounts(!showTestAccounts)}
            className="w-full py-3 border-2 border-gray-200 rounded-lg hover:bg-gray-50 transition mb-4 font-medium text-gray-700"
          >
            {showTestAccounts ? '🔒 Masquer' : '🧪'} Comptes de Test
          </button>

          {/* Test Accounts List */}
          {showTestAccounts && (
            <div className="space-y-3 mb-6">
              <p className="text-sm text-gray-600 mb-3">
                Cliquez sur un compte pour remplir automatiquement les champs :
              </p>
              {testAccounts.map((account) => (
                <button
                  key={account.email}
                  onClick={() => handleTestAccount(account.email, account.password)}
                  className={`w-full p-4 bg-gradient-to-r ${account.color} rounded-lg text-white text-left hover:shadow-lg transition`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      <span className="text-2xl mr-3">{account.icon}</span>
                      <span className="font-bold">{account.role}</span>
                    </div>
                  </div>
                  <div className="text-sm opacity-90 mb-1">📧 {account.email}</div>
                  <div className="text-sm opacity-90">🔑 {account.password}</div>
                </button>
              ))}
            </div>
          )}

          {/* Register Link */}
          <div className="text-center pt-4 border-t">
            <p className="text-gray-600">
              Pas encore de compte ?{' '}
              <button
                onClick={onSwitchToRegister}
                className="text-green-600 hover:text-green-700 font-bold"
              >
                S'inscrire
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
