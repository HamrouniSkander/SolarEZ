import { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'particulier' | 'installateur' | 'formation' | 'fournisseur' | 'admin';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  company?: string;
  location?: string;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  register: (userData: any) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Comptes de test prédéfinis
const TEST_USERS: { [key: string]: User & { password: string } } = {
  // 1. Particulier
  'karim.ben@gmail.com': {
    id: '1',
    email: 'karim.ben@gmail.com',
    password: 'particulier123',
    name: 'Karim Ben Ali',
    role: 'particulier',
    location: 'Tunis',
    avatar: '👤'
  },
  
  // 2. Installateur
  'contact@sunpower.tn': {
    id: '2',
    email: 'contact@sunpower.tn',
    password: 'installateur123',
    name: 'Mohamed Ayari',
    role: 'installateur',
    company: 'SunPower Tunisia',
    location: 'Tunis',
    avatar: '🔧'
  },
  
  // 3. Centre de Formation
  'info@solaracademy.tn': {
    id: '3',
    email: 'info@solaracademy.tn',
    password: 'formation123',
    name: 'Amira Khalil',
    role: 'formation',
    company: 'SolarAcademy Tunisia',
    location: 'Sousse',
    avatar: '🎓'
  },
  
  // 4. Fournisseur
  'sales@solarpro.tn': {
    id: '4',
    email: 'sales@solarpro.tn',
    password: 'fournisseur123',
    name: 'Riadh Mansour',
    role: 'fournisseur',
    company: 'SolarPro Equipment',
    location: 'Sfax',
    avatar: '📦'
  },
  
  // 5. Super Admin
  'admin@solarez.tn': {
    id: '5',
    email: 'admin@solarez.tn',
    password: 'admin123',
    name: 'Admin SolarEZ',
    role: 'admin',
    company: 'SolarEZ',
    location: 'Tunis',
    avatar: '👑'
  }
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = (email: string, password: string): boolean => {
    const testUser = TEST_USERS[email];
    
    if (testUser && testUser.password === password) {
      const { password: _, ...userWithoutPassword } = testUser;
      setUser(userWithoutPassword);
      localStorage.setItem('solarez_user', JSON.stringify(userWithoutPassword));
      return true;
    }
    
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('solarez_user');
  };

  const register = (userData: any): boolean => {
    // Simulation d'inscription
    const newUser: User = {
      id: Date.now().toString(),
      email: userData.email,
      name: userData.name,
      role: userData.role || 'particulier',
      company: userData.company,
      location: userData.location,
      avatar: userData.role === 'particulier' ? '👤' : 
              userData.role === 'installateur' ? '🔧' :
              userData.role === 'formation' ? '🎓' :
              userData.role === 'fournisseur' ? '📦' : '👤'
    };
    
    setUser(newUser);
    localStorage.setItem('solarez_user', JSON.stringify(newUser));
    return true;
  };

  // Charger l'utilisateur depuis le localStorage au démarrage
  useState(() => {
    const savedUser = localStorage.getItem('solarez_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  });

  return (
    <AuthContext.Provider value={{ user, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
