import { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Hero } from './components/Hero';
import { EnergySimulator } from './components/EnergySimulator';
import { Installers } from './components/Installers';
import { Formations } from './components/Formations';
import { Jobs } from './components/Jobs';
import { Footer } from './components/Footer';
import { QuoteResult } from './components/QuoteResult';
import { Login } from './components/Login';
import { Register } from './components/Register';
import { UserMenu } from './components/UserMenu';
import { Dashboard } from './components/Dashboard';

export type SimulationResult = {
  powerKWc: number;
  numPanels: number;
  totalCost: number;
  monthlyEconomies: number;
  annualEconomies: number;
  roi: number;
  annualProduction: number;
  co2Reduction: number;
  monthlyConsumption: number;
  region: string;
  roofType: string;
  orientation: string;
};

function AppContent() {
  const { user } = useAuth();
  const [activeSection, setActiveSection] = useState<'home' | 'simulator' | 'installers' | 'formations' | 'jobs' | 'dashboard'>('home');
  const [quoteResult, setQuoteResult] = useState<SimulationResult | null>(null);
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);

  const handleSimulationComplete = (result: SimulationResult) => {
    setQuoteResult(result);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToHome = () => {
    setActiveSection('home');
    setQuoteResult(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Navigation */}
      <nav className="bg-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center cursor-pointer" onClick={handleBackToHome}>
              <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
                <span className="text-2xl">☀️</span>
              </div>
              <span className="ml-3 text-xl font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                SolarEZ
              </span>
            </div>
            
            <div className="hidden md:flex space-x-8">
              <button 
                onClick={() => setActiveSection('home')}
                className={`${activeSection === 'home' ? 'text-green-600' : 'text-gray-700'} hover:text-green-600 transition`}
              >
                Accueil
              </button>
              <button 
                onClick={() => setActiveSection('simulator')}
                className={`${activeSection === 'simulator' ? 'text-green-600' : 'text-gray-700'} hover:text-green-600 transition`}
              >
                Simulation
              </button>
              <button 
                onClick={() => setActiveSection('installers')}
                className={`${activeSection === 'installers' ? 'text-green-600' : 'text-gray-700'} hover:text-green-600 transition`}
              >
                Installateurs
              </button>
              <button 
                onClick={() => setActiveSection('formations')}
                className={`${activeSection === 'formations' ? 'text-green-600' : 'text-gray-700'} hover:text-green-600 transition`}
              >
                Formations
              </button>
              <button 
                onClick={() => setActiveSection('jobs')}
                className={`${activeSection === 'jobs' ? 'text-green-600' : 'text-gray-700'} hover:text-green-600 transition`}
              >
                Emploi
              </button>
            </div>

            <div className="flex items-center space-x-4">
              {user ? (
                <UserMenu onDashboard={() => setActiveSection('dashboard')} />
              ) : (
                <>
                  <button 
                    onClick={() => setShowLogin(true)}
                    className="px-4 py-2 text-green-600 hover:text-green-700 transition"
                  >
                    Connexion
                  </button>
                  <button 
                    onClick={() => setShowRegister(true)}
                    className="px-4 py-2 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition"
                  >
                    S'inscrire
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main>
        {quoteResult ? (
          <QuoteResult result={quoteResult} onBack={handleBackToHome} onContactInstaller={() => setActiveSection('installers')} />
        ) : (
          <>
            {activeSection === 'home' && (
              <Hero onStartSimulation={() => setActiveSection('simulator')} />
            )}
            {activeSection === 'simulator' && (
              <EnergySimulator onSimulationComplete={handleSimulationComplete} />
            )}
            {activeSection === 'installers' && <Installers />}
            {activeSection === 'formations' && <Formations />}
            {activeSection === 'jobs' && <Jobs />}
            {activeSection === 'dashboard' && <Dashboard onBack={handleBackToHome} />}
          </>
        )}
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals */}
      {showLogin && (
        <Login 
          onClose={() => setShowLogin(false)} 
          onSwitchToRegister={() => {
            setShowLogin(false);
            setShowRegister(true);
          }}
        />
      )}
      {showRegister && (
        <Register 
          onClose={() => setShowRegister(false)} 
          onSwitchToLogin={() => {
            setShowRegister(false);
            setShowLogin(true);
          }}
        />
      )}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;