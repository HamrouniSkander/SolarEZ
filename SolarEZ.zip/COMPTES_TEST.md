# 🧪 COMPTES DE TEST SOLAREZ

## Accès Rapide aux Comptes de Démonstration

La plateforme SolarEZ inclut 5 comptes de test prédéfinis pour explorer toutes les fonctionnalités selon chaque profil d'utilisateur.

---

## 📋 Liste Complète des Comptes

### 1️⃣ PARTICULIER / ENTREPRISE
**Profil :** Client final souhaitant installer des panneaux solaires

```
👤 Nom: Karim Ben Ali
📧 Email: karim.ben@gmail.com
🔑 Mot de passe: particulier123
📍 Localisation: Tunis
```

**Accès Dashboard :**
- Simulations énergétiques réalisées
- Devis en attente
- Installateurs contactés
- Historique des projets
- Accès formations et emploi

---

### 2️⃣ INSTALLATEUR PHOTOVOLTAÏQUE
**Profil :** Professionnel de l'installation solaire

```
🔧 Nom: Mohamed Ayari
🏢 Entreprise: SunPower Tunisia
📧 Email: contact@sunpower.tn
🔑 Mot de passe: installateur123
📍 Localisation: Tunis
```

**Accès Dashboard :**
- Leads qualifiés en temps réel
- Gestion des devis clients
- Commandes fournisseurs
- Publication offres d'emploi
- Statistiques CA et projets

---

### 3️⃣ CENTRE DE FORMATION
**Profil :** Organisme proposant des formations photovoltaïques

```
🎓 Nom: Amira Khalil
🏢 Centre: SolarAcademy Tunisia
📧 Email: info@solaracademy.tn
🔑 Mot de passe: formation123
📍 Localisation: Sousse
```

**Accès Dashboard :**
- Publication de formations
- Gestion des inscriptions
- Sessions à venir
- Étudiants inscrits
- Revenus et statistiques

---

### 4️⃣ FOURNISSEUR / GROSSISTE
**Profil :** Vendeur de matériel photovoltaïque

```
📦 Nom: Riadh Mansour
🏢 Entreprise: SolarPro Equipment
📧 Email: sales@solarpro.tn
🔑 Mot de passe: fournisseur123
📍 Localisation: Sfax
```

**Accès Dashboard :**
- Catalogue produits (panneaux, onduleurs, batteries)
- Commandes en cours
- Clients actifs
- Gestion stock et disponibilités
- Chiffre d'affaires

---

### 5️⃣ SUPER ADMIN
**Profil :** Administrateur de la plateforme SolarEZ

```
👑 Nom: Admin SolarEZ
🏢 Organisation: SolarEZ
📧 Email: admin@solarez.tn
🔑 Mot de passe: admin123
📍 Localisation: Tunis
```

**Accès Dashboard :**
- Vue globale plateforme
- Validation nouveaux comptes
- Modération publicités
- Statistiques utilisateurs
- Analytics et reporting
- Gestion contenus

---

## 🚀 Comment Utiliser les Comptes de Test ?

### Méthode 1 : Connexion Manuelle
1. Cliquez sur **"Connexion"** dans la navigation
2. Saisissez l'email et le mot de passe
3. Cliquez sur **"Se Connecter"**

### Méthode 2 : Connexion Rapide (Recommandée)
1. Cliquez sur **"Connexion"**
2. Cliquez sur **"🧪 Comptes de Test"**
3. Cliquez directement sur le profil souhaité
4. Les champs se remplissent automatiquement
5. Cliquez sur **"Se Connecter"**

---

## 🎯 Parcours de Test Recommandés

### Parcours Particulier
1. Se connecter avec le compte Particulier
2. Aller dans **"Simulation"**
3. Compléter le bilan énergétique en 3 étapes
4. Consulter le devis généré
5. Explorer les installateurs disponibles
6. Consulter son tableau de bord

### Parcours Installateur
1. Se connecter avec le compte Installateur
2. Consulter les nouveaux leads dans le dashboard
3. Créer un devis pour un client
4. Commander du matériel (fournisseurs)
5. Publier une offre d'emploi

### Parcours Centre de Formation
1. Se connecter avec le compte Formation
2. Publier une nouvelle formation
3. Gérer les inscriptions
4. Consulter les prochaines sessions

### Parcours Fournisseur
1. Se connecter avec le compte Fournisseur
2. Ajouter des produits au catalogue
3. Gérer les commandes en cours
4. Communiquer avec les installateurs

### Parcours Admin
1. Se connecter avec le compte Admin
2. Visualiser les statistiques globales
3. Valider les nouveaux comptes professionnels
4. Modérer les publicités
5. Consulter les rapports

---

## 🔐 Sécurité & Notes

- Ces comptes sont **uniquement pour la démonstration**
- Les mots de passe sont simples pour faciliter les tests
- En production, un système d'authentification robuste serait implémenté
- Les données affichées sont des données de démonstration

---

## 📊 Tableau Récapitulatif

| Rôle | Email | Mot de passe | Icône |
|------|-------|--------------|-------|
| Particulier | karim.ben@gmail.com | particulier123 | 👤 |
| Installateur | contact@sunpower.tn | installateur123 | 🔧 |
| Formation | info@solaracademy.tn | formation123 | 🎓 |
| Fournisseur | sales@solarpro.tn | fournisseur123 | 📦 |
| Admin | admin@solarez.tn | admin123 | 👑 |

---

## ✨ Fonctionnalités Testables

### Pour Tous les Utilisateurs
- ✅ Connexion / Déconnexion
- ✅ Inscription nouveau compte
- ✅ Navigation entre sections
- ✅ Consultation formations
- ✅ Consultation offres emploi
- ✅ Simulation énergétique

### Spécifique par Rôle
- **Particulier :** Simulation complète, devis PDF, contact installateurs
- **Installateur :** Gestion leads, création devis, commandes fournisseurs
- **Formation :** Publication formations, gestion étudiants, sessions
- **Fournisseur :** Catalogue produits, gestion commandes, stock
- **Admin :** Validation comptes, modération, analytics globales

---

## 💡 Conseils d'Utilisation

1. **Testez d'abord en tant que Particulier** pour comprendre le parcours client
2. **Ensuite testez Installateur** pour voir la partie professionnelle
3. **Explorez Admin** pour la vue complète de la plateforme
4. **Utilisez le bouton de déconnexion** dans le menu utilisateur pour changer de compte
5. **Le dashboard est accessible** via l'icône de profil en haut à droite

---

## 🛠️ Prochaines Étapes (Production)

Pour une version production complète, il faudrait :
- Système d'authentification sécurisé (JWT, OAuth)
- Base de données (Supabase recommandé)
- Vérification email
- Reset mot de passe
- Authentification multi-facteurs (2FA)
- Gestion des rôles et permissions
- Logs et audit trail

---

**Créé pour la démonstration de la plateforme SolarEZ**
*Plateforme digitale du photovoltaïque en Tunisie*
