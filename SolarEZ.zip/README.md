
  # Design

  This is a code bundle for Design. The original project is available at https://www.figma.com/design/sox6qWhI7z19Lg91rqOx9b/Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  